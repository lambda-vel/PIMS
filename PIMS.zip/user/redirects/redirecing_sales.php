<?php
    include "../includes/header.php";
    include "../config/connection.php";
    sleep(2);
    header('Location: ../sales/sales.php');
?>