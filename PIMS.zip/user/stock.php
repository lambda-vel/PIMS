<!DOCTYPE html>
<?php
    include "includes/header.php";
    include "../config/connection.php";
?>

<html>
<head>
    <title>Store | PIMS</title>
</head>
<body>
  <br>
    <div class="container-fluid">
    <h5>Stock Status</h5>
    <br><br>
    <div>
    <table class="table table-striped">
      <tr>
        <td><a class="btn btn-info" href="centralstore.php">Central Store</a></td>
        <td><a class="btn btn-info" href="headoffice.php">Head Office</a></td>
        <td><a class="btn btn-info" href="outlet.php">Outlet</a></td>
      </tr>
    </table>
    </div>
    
    </div>
</body>
</html>