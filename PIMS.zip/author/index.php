<?php
  header('Location: my_books.php');
?>